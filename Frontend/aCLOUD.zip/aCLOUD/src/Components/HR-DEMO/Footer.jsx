import React from 'react';

const Footer = () => {
    return (
        <>
            <div className="text-center mx-auto mt-5 p-2 w-50 text-white" style={{ backgroundColor: "#505F79" }}>
                Copyright 2022 - All rights reserved
            </div>
        </>
    )
}

export default Footer;